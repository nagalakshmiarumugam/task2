import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, User, Settings, Bell, Heart, Baby, Calendar, Trash2 } from "lucide-react";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { useToast } from "@/hooks/use-toast";

interface UserProfile {
  name: string;
  dueDate: string;
  deliveryDate: string;
  babyName: string;
  doctorName: string;
  emergencyContact: string;
  notes: string;
}

interface AppSettings {
  notifications: boolean;
  reminderFrequency: number;
  darkMode: boolean;
  dataBackup: boolean;
}

export default function Profile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [profile, setProfile] = useLocalStorage<UserProfile>("user-profile", {
    name: "",
    dueDate: "",
    deliveryDate: "",
    babyName: "",
    doctorName: "",
    emergencyContact: "",
    notes: ""
  });

  const [settings, setSettings] = useLocalStorage<AppSettings>("app-settings", {
    notifications: true,
    reminderFrequency: 4,
    darkMode: false,
    dataBackup: true
  });

  const [isEditing, setIsEditing] = useState(false);
  const [tempProfile, setTempProfile] = useState(profile);

  useEffect(() => {
    setTempProfile(profile);
  }, [profile]);

  const handleSaveProfile = () => {
    setProfile(tempProfile);
    setIsEditing(false);
    toast({
      title: "Profile updated",
      description: "Your profile information has been saved successfully.",
    });
  };

  const handleCancelEdit = () => {
    setTempProfile(profile);
    setIsEditing(false);
  };

  const updateSetting = (key: keyof AppSettings, value: boolean | number) => {
    setSettings({ ...settings, [key]: value });
    toast({
      title: "Settings updated",
      description: "Your preferences have been saved.",
    });
  };

  const clearAllData = () => {
    if (window.confirm("Are you sure you want to clear all your data? This action cannot be undone.")) {
      // Clear all localStorage data related to the app
      localStorage.removeItem("user-profile");
      localStorage.removeItem("app-settings");
      localStorage.removeItem("recovery-data");
      localStorage.removeItem("journal-entries");
      localStorage.removeItem("reminders");
      localStorage.removeItem("baby-logs");
      
      // Reset state
      setProfile({
        name: "",
        dueDate: "",
        deliveryDate: "",
        babyName: "",
        doctorName: "",
        emergencyContact: "",
        notes: ""
      });
      setSettings({
        notifications: true,
        reminderFrequency: 4,
        darkMode: false,
        dataBackup: true
      });
      
      toast({
        title: "Data cleared",
        description: "All your data has been removed from this device.",
      });
    }
  };

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <User className="h-5 w-5 text-soft-pink" />
          <h1 className="text-lg font-medium">Profile</h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Personal Information */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center space-x-2">
                <Heart className="h-5 w-5 text-soft-pink" />
                <span>Personal Information</span>
              </CardTitle>
              <Button
                variant={isEditing ? "outline" : "default"}
                size="sm"
                onClick={() => isEditing ? handleCancelEdit() : setIsEditing(true)}
                className={isEditing ? "" : "bg-soft-pink hover:bg-soft-pink/90 text-white"}
              >
                {isEditing ? "Cancel" : "✏️ Edit Profile"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isEditing && (
              <div className="p-3 bg-soft-pink/10 rounded-lg border border-soft-pink/20">
                <p className="text-sm text-gray-600">
                  👆 Click "✏️ Edit Profile" above to modify your information
                </p>
              </div>
            )}
            <div className="grid gap-4">
              <div>
                <Label htmlFor="name">Your Name</Label>
                <Input
                  id="name"
                  value={isEditing ? tempProfile.name : profile.name}
                  onChange={(e) => setTempProfile({ ...tempProfile, name: e.target.value })}
                  disabled={!isEditing}
                  placeholder="Enter your name"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={isEditing ? tempProfile.dueDate : profile.dueDate}
                    onChange={(e) => setTempProfile({ ...tempProfile, dueDate: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div>
                  <Label htmlFor="deliveryDate">Delivery Date</Label>
                  <Input
                    id="deliveryDate"
                    type="date"
                    value={isEditing ? tempProfile.deliveryDate : profile.deliveryDate}
                    onChange={(e) => setTempProfile({ ...tempProfile, deliveryDate: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="babyName">Baby's Name</Label>
                <Input
                  id="babyName"
                  value={isEditing ? tempProfile.babyName : profile.babyName}
                  onChange={(e) => setTempProfile({ ...tempProfile, babyName: e.target.value })}
                  disabled={!isEditing}
                  placeholder="Enter baby's name"
                />
              </div>

              <div>
                <Label htmlFor="doctorName">Healthcare Provider</Label>
                <Input
                  id="doctorName"
                  value={isEditing ? tempProfile.doctorName : profile.doctorName}
                  onChange={(e) => setTempProfile({ ...tempProfile, doctorName: e.target.value })}
                  disabled={!isEditing}
                  placeholder="Doctor or midwife name"
                />
              </div>

              <div>
                <Label htmlFor="emergencyContact">Emergency Contact</Label>
                <Input
                  id="emergencyContact"
                  value={isEditing ? tempProfile.emergencyContact : profile.emergencyContact}
                  onChange={(e) => setTempProfile({ ...tempProfile, emergencyContact: e.target.value })}
                  disabled={!isEditing}
                  placeholder="Phone number or contact info"
                />
              </div>

              <div>
                <Label htmlFor="notes">Personal Notes</Label>
                <Textarea
                  id="notes"
                  value={isEditing ? tempProfile.notes : profile.notes}
                  onChange={(e) => setTempProfile({ ...tempProfile, notes: e.target.value })}
                  disabled={!isEditing}
                  placeholder="Any important notes about your recovery or care"
                  rows={3}
                />
              </div>
            </div>

            {isEditing && (
              <div className="flex space-x-2 pt-2">
                <Button onClick={handleSaveProfile} className="flex-1">
                  Save Changes
                </Button>
                <Button variant="outline" onClick={handleCancelEdit} className="flex-1">
                  Cancel
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* App Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5 text-soft-blue" />
              <span>App Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Notifications</Label>
                <p className="text-xs text-gray-500">
                  Receive reminders for self-care and tracking
                </p>
              </div>
              <Switch
                checked={settings.notifications}
                onCheckedChange={(checked) => updateSetting("notifications", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-sm font-medium">Data Backup</Label>
                <p className="text-xs text-gray-500">
                  Keep your data safe on this device
                </p>
              </div>
              <Switch
                checked={settings.dataBackup}
                onCheckedChange={(checked) => updateSetting("dataBackup", checked)}
              />
            </div>

            <div>
              <Label className="text-sm font-medium">Daily Reminder Frequency</Label>
              <p className="text-xs text-gray-500 mb-2">
                How many times per day should we remind you to check in?
              </p>
              <div className="flex space-x-2">
                {[1, 2, 3, 4, 5].map((freq) => (
                  <Button
                    key={freq}
                    variant={settings.reminderFrequency === freq ? "default" : "outline"}
                    size="sm"
                    onClick={() => updateSetting("reminderFrequency", freq)}
                    className="w-10 h-10"
                  >
                    {freq}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-calm-green" />
              <span>Quick Actions</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => setLocation('/baby-profile')}
            >
              <Baby className="h-4 w-4 mr-2" />
              View Baby Profile
            </Button>
            
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => setLocation('/emergency')}
            >
              <Bell className="h-4 w-4 mr-2" />
              Emergency Contacts
            </Button>
          </CardContent>
        </Card>

        {/* Data Management */}
        <Card className="border-red-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-red-600">
              <Trash2 className="h-5 w-5" />
              <span>Data Management</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-4">
              This will permanently delete all your tracking data, journal entries, and settings from this device.
            </p>
            <Button
              variant="destructive"
              onClick={clearAllData}
              className="w-full"
            >
              Clear All Data
            </Button>
          </CardContent>
        </Card>

        {/* App Info */}
        <Card className="gentle-coral-light">
          <CardContent className="p-4 text-center">
            <h3 className="font-medium text-gray-800 mb-2">Postpartum Recovery Companion</h3>
            <p className="text-sm text-gray-600">
              Supporting your journey to wellness, one day at a time.
            </p>
            <p className="text-xs text-gray-500 mt-2">
              All data is stored securely on your device
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}