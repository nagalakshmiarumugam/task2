import { useState } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { WELLNESS_EXERCISES } from "@/lib/constants";
import { ArrowLeft, Play, Pause, RotateCcw, Heart } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

export default function Wellness() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [currentExercise, setCurrentExercise] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [timer, setTimer] = useState<NodeJS.Timeout | null>(null);

  const startExercise = (exerciseId: string) => {
    const exercise = WELLNESS_EXERCISES.find(e => e.id === exerciseId);
    if (!exercise) return;

    setCurrentExercise(exerciseId);
    setTimeRemaining(exercise.duration * 60); // Convert to seconds
    setProgress(0);
    setIsPlaying(true);

    // Start timer
    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsPlaying(false);
          setCurrentExercise(null);
          toast({
            title: "Exercise complete!",
            description: "Great job on completing your wellness exercise.",
          });
          return 0;
        }
        return prev - 1;
      });

      setProgress((prev) => {
        const newProgress = ((exercise.duration * 60 - timeRemaining + 1) / (exercise.duration * 60)) * 100;
        return Math.min(newProgress, 100);
      });
    }, 1000);

    setTimer(interval);
  };

  const pauseExercise = () => {
    if (timer) {
      clearInterval(timer);
      setTimer(null);
    }
    setIsPlaying(false);
  };

  const resumeExercise = () => {
    if (!currentExercise) return;
    
    const interval = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsPlaying(false);
          setCurrentExercise(null);
          toast({
            title: "Exercise complete!",
            description: "Great job on completing your wellness exercise.",
          });
          return 0;
        }
        return prev - 1;
      });

      setProgress((prev) => {
        const exercise = WELLNESS_EXERCISES.find(e => e.id === currentExercise);
        if (!exercise) return prev;
        const newProgress = ((exercise.duration * 60 - timeRemaining + 1) / (exercise.duration * 60)) * 100;
        return Math.min(newProgress, 100);
      });
    }, 1000);

    setTimer(interval);
    setIsPlaying(true);
  };

  const resetExercise = () => {
    if (timer) {
      clearInterval(timer);
      setTimer(null);
    }
    setCurrentExercise(null);
    setIsPlaying(false);
    setProgress(0);
    setTimeRemaining(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getExerciseIcon = (type: string) => {
    switch (type) {
      case 'breathing': return '🫁';
      case 'meditation': return '🧘‍♀️';
      case 'stretching': return '🤸‍♀️';
      case 'pep-talk': return '💪';
      default: return '🌟';
    }
  };

  const getExerciseColor = (type: string) => {
    switch (type) {
      case 'breathing': return 'soft-blue';
      case 'meditation': return 'soft-lavender';
      case 'stretching': return 'calm-green';
      case 'pep-talk': return 'warm-yellow';
      default: return 'soft-pink';
    }
  };

  const currentExerciseData = currentExercise 
    ? WELLNESS_EXERCISES.find(e => e.id === currentExercise)
    : null;

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <Heart className="h-5 w-5 text-gray-600" />
          <h1 className="text-lg font-medium">Wellness Exercises</h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Current Exercise Player */}
        {currentExercise && currentExerciseData && (
          <Card className="soft-pink-light border-soft-pink">
            <CardContent className="p-4">
              <div className="text-center space-y-4">
                <div className="text-4xl">{getExerciseIcon(currentExerciseData.type)}</div>
                <h3 className="font-medium text-gray-800">{currentExerciseData.title}</h3>
                
                {/* Progress Bar */}
                <div className="space-y-2">
                  <Progress value={progress} className="h-2" />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>{formatTime(currentExerciseData.duration * 60 - timeRemaining)}</span>
                    <span>{formatTime(timeRemaining)}</span>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex justify-center space-x-3">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={resetExercise}
                    className="rounded-full"
                  >
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                  
                  <Button
                    size="icon"
                    onClick={isPlaying ? pauseExercise : resumeExercise}
                    className="rounded-full w-12 h-12 bg-soft-pink hover:bg-soft-pink/90"
                  >
                    {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Welcome Message */}
        <Card className="soft-lavender-light border-soft-lavender">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="text-2xl">🌸</div>
              <div>
                <p className="font-medium text-gray-800">Take a moment for yourself</p>
                <p className="text-sm text-gray-600">
                  These exercises are designed to help you relax and recharge
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Exercise List */}
        <div className="space-y-3">
          <h3 className="font-medium text-gray-800">Available Exercises</h3>
          
          {WELLNESS_EXERCISES.map((exercise) => (
            <Card key={exercise.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="text-2xl">{getExerciseIcon(exercise.type)}</div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-800">{exercise.title}</h4>
                      <p className="text-sm text-gray-600">{exercise.description}</p>
                      <div className="flex items-center space-x-3 mt-1">
                        <span className="text-xs text-gray-500">{exercise.duration} minutes</span>
                        <span className={`text-xs px-2 py-1 rounded-full ${getExerciseColor(exercise.type)}-light`}>
                          {exercise.type.charAt(0).toUpperCase() + exercise.type.slice(1)}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <Button
                    size="icon"
                    onClick={() => startExercise(exercise.id)}
                    disabled={currentExercise === exercise.id}
                    className={`rounded-full ${getExerciseColor(exercise.type)} hover:opacity-90`}
                  >
                    <Play className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Wellness Tips */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>💡</span>
              <span>Wellness Tips</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="text-lg">🕒</div>
              <div>
                <p className="text-sm font-medium">Best Times to Practice</p>
                <p className="text-xs text-gray-600">Morning after waking, during baby's nap, or before bed</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="text-lg">🎧</div>
              <div>
                <p className="text-sm font-medium">Create a Quiet Space</p>
                <p className="text-xs text-gray-600">Find a comfortable spot where you won't be interrupted</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="text-lg">🔄</div>
              <div>
                <p className="text-sm font-medium">Make it a Habit</p>
                <p className="text-xs text-gray-600">Even 5 minutes daily can make a significant difference</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Encouragement */}
        <Card className="calm-green-light border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="text-2xl">🤗</div>
              <div>
                <p className="font-medium text-gray-800">You deserve this time</p>
                <p className="text-sm text-gray-600">
                  Taking care of yourself helps you take better care of your baby.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
