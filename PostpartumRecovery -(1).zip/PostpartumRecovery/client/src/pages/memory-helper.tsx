import { useState } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { MemoryNote } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ArrowLeft, Plus, Brain, Trash2, AlertCircle, Clock } from "lucide-react";
import { useLocation } from "wouter";

export default function MemoryHelper() {
  const [, setLocation] = useLocation();
  const { memoryNotes, addMemoryNote, updateMemoryNote, deleteMemoryNote, getUrgentNotes } = useRecoveryData();
  const { toast } = useToast();
  
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [content, setContent] = useState("");
  const [type, setType] = useState<"medication" | "appointment" | "milestone" | "general">("general");
  const [priority, setPriority] = useState<"low" | "medium" | "high">("medium");
  const [alertTime, setAlertTime] = useState("");

  const urgentNotes = getUrgentNotes();

  const handleAddNote = () => {
    if (!content.trim()) {
      toast({
        title: "Error",
        description: "Please enter some content for your note.",
        variant: "destructive",
      });
      return;
    }

    const newNote: MemoryNote = {
      id: `note_${Date.now()}`,
      content: content.trim(),
      type,
      priority,
      alertTime: alertTime || undefined,
      completed: false,
      createdAt: new Date().toISOString(),
    };

    addMemoryNote(newNote);
    
    toast({
      title: "Note added",
      description: "Your memory note has been saved.",
    });

    setShowAddDialog(false);
    setContent("");
    setType("general");
    setPriority("medium");
    setAlertTime("");
  };

  const handleToggleComplete = (id: string, completed: boolean) => {
    updateMemoryNote(id, { completed });
    
    if (completed) {
      toast({
        title: "Task completed",
        description: "Great job staying on top of things!",
      });
    }
  };

  const handleDeleteNote = (id: string) => {
    deleteMemoryNote(id);
    toast({
      title: "Note deleted",
      description: "The note has been removed.",
    });
  };

  const getTypeIcon = (noteType: string) => {
    switch (noteType) {
      case 'medication': return '💊';
      case 'appointment': return '📅';
      case 'milestone': return '🌟';
      case 'general': return '📝';
      default: return '📝';
    }
  };

  const getTypeColor = (noteType: string) => {
    switch (noteType) {
      case 'medication': return 'bg-red-100 text-red-700';
      case 'appointment': return 'bg-blue-100 text-blue-700';
      case 'milestone': return 'bg-yellow-100 text-yellow-700';
      case 'general': return 'bg-gray-100 text-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getPriorityColor = (notePriority: string) => {
    switch (notePriority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const sortedNotes = [...memoryNotes].sort((a, b) => {
    // First sort by completion status
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    
    // Then by priority
    const priorityOrder = { high: 3, medium: 2, low: 1 };
    const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
    if (priorityDiff !== 0) return priorityDiff;
    
    // Finally by creation date (newest first)
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-gray-600" />
            <h1 className="text-lg font-medium">Memory Helper</h1>
          </div>
        </div>
        
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-soft-pink hover:bg-soft-pink/90">
              <Plus className="h-4 w-4 mr-1" />
              Add Note
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add Memory Note</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="content">Note</Label>
                <Textarea
                  id="content"
                  placeholder="What do you want to remember?"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="resize-none"
                  rows={3}
                />
              </div>
              
              <div>
                <Label htmlFor="type">Type</Label>
                <Select value={type} onValueChange={(value: any) => setType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="medication">💊 Medication</SelectItem>
                    <SelectItem value="appointment">📅 Appointment</SelectItem>
                    <SelectItem value="milestone">🌟 Milestone</SelectItem>
                    <SelectItem value="general">📝 General</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="priority">Priority</Label>
                <Select value={priority} onValueChange={(value: any) => setPriority(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="alertTime">Alert Time (optional)</Label>
                <Input
                  id="alertTime"
                  type="datetime-local"
                  value={alertTime}
                  onChange={(e) => setAlertTime(e.target.value)}
                />
              </div>
              
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setShowAddDialog(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleAddNote} className="flex-1">
                  Add Note
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Urgent Notes Alert */}
        {urgentNotes.length > 0 && (
          <Card className="gentle-coral-light border-red-200">
            <CardContent className="p-4">
              <div className="flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
                <div>
                  <p className="font-medium text-red-800">
                    {urgentNotes.length} high priority note{urgentNotes.length !== 1 ? 's' : ''} pending
                  </p>
                  <p className="text-sm text-red-700">
                    Don't forget about your important tasks!
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Notes Summary */}
        {memoryNotes.length > 0 && (
          <Card className="soft-blue-light border-soft-blue">
            <CardContent className="p-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-soft-pink">
                    {memoryNotes.filter(n => !n.completed).length}
                  </div>
                  <div className="text-xs text-gray-600">Pending</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-soft-blue">
                    {memoryNotes.filter(n => n.completed).length}
                  </div>
                  <div className="text-xs text-gray-600">Completed</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-soft-lavender">
                    {memoryNotes.length}
                  </div>
                  <div className="text-xs text-gray-600">Total Notes</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Notes List */}
        {sortedNotes.length > 0 ? (
          <div className="space-y-3">
            {sortedNotes.map((note) => (
              <Card key={note.id} className={note.completed ? "opacity-60" : ""}>
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      checked={note.completed}
                      onCheckedChange={(checked) => handleToggleComplete(note.id, !!checked)}
                      className="mt-1"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className={`text-sm ${note.completed ? 'line-through text-gray-500' : 'text-gray-800'}`}>
                            {note.content}
                          </p>
                          
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge className={`text-xs ${getTypeColor(note.type)}`} variant="secondary">
                              {getTypeIcon(note.type)} {note.type}
                            </Badge>
                            <Badge className={`text-xs ${getPriorityColor(note.priority)}`} variant="outline">
                              {note.priority}
                            </Badge>
                          </div>
                          
                          {note.alertTime && (
                            <div className="flex items-center space-x-1 mt-2 text-xs text-gray-500">
                              <Clock className="h-3 w-3" />
                              <span>Alert: {format(new Date(note.alertTime), 'MMM d, h:mm a')}</span>
                            </div>
                          )}
                          
                          <p className="text-xs text-gray-500 mt-1">
                            Created {format(new Date(note.createdAt), 'MMM d, yyyy')}
                          </p>
                        </div>
                        
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-gray-400 hover:text-red-500"
                          onClick={() => handleDeleteNote(note.id)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          /* Empty State */
          <Card>
            <CardContent className="text-center py-12">
              <div className="text-6xl mb-4">🧠</div>
              <h3 className="font-medium text-gray-800 mb-2">No notes yet</h3>
              <p className="text-sm text-gray-600 mb-4">
                Start adding things you want to remember during this busy time
              </p>
              <Button 
                onClick={() => setShowAddDialog(true)}
                className="bg-soft-pink hover:bg-soft-pink/90"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Note
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Memory Helper Tips */}
        <Card className="soft-lavender-light border-soft-lavender">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="text-xl">💡</div>
              <div>
                <h3 className="font-medium text-gray-800 mb-2">Memory Helper Tips</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Use this for medication schedules and doctor appointments</li>
                  <li>• Record special baby milestones you don't want to forget</li>
                  <li>• Set alerts for time-sensitive reminders</li>
                  <li>• Mark tasks as complete when done for satisfaction</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Encouragement */}
        <Card className="warm-yellow-light border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="text-2xl">🤗</div>
              <div>
                <p className="font-medium text-gray-800">It's okay to need reminders</p>
                <p className="text-sm text-gray-600">
                  Sleep deprivation affects memory. You're doing great by staying organized!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
