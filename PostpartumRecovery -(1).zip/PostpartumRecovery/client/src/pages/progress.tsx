import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ProgressRing } from "@/components/ui/progress-ring";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { format, subDays, startOfWeek, endOfWeek, eachDayOfInterval } from "date-fns";
import { ArrowLeft, TrendingUp, Calendar, Award } from "lucide-react";
import { useLocation } from "wouter";

export default function Progress() {
  const [, setLocation] = useLocation();
  const { dailyEntries, journalEntries, getWeeklyProgress } = useRecoveryData();
  
  const weekProgress = getWeeklyProgress();
  const now = new Date();
  const weekStart = startOfWeek(now);
  const weekEnd = endOfWeek(now);
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });

  // Calculate mood trend over the last 7 days
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = format(subDays(now, 6 - i), 'yyyy-MM-dd');
    const entry = dailyEntries.find(e => e.date === date);
    return {
      date,
      mood: entry?.mood.mood,
      pain: entry?.pain.level,
      sleep: entry?.sleep.quality,
    };
  });

  const getMoodScore = (mood?: string) => {
    switch (mood) {
      case 'very-happy': return 5;
      case 'happy': return 4;
      case 'neutral': return 3;
      case 'sad': return 2;
      case 'very-sad': return 1;
      default: return 0;
    }
  };

  const getSleepScore = (quality?: string) => {
    switch (quality) {
      case 'excellent': return 4;
      case 'good': return 3;
      case 'fair': return 2;
      case 'poor': return 1;
      default: return 0;
    }
  };

  const averageMood = last7Days.reduce((sum, day) => sum + getMoodScore(day.mood), 0) / 7;
  const averagePain = last7Days.reduce((sum, day) => sum + (day.pain || 0), 0) / 7;
  const averageSleep = last7Days.reduce((sum, day) => sum + getSleepScore(day.sleep), 0) / 7;

  const achievements = [
    {
      id: 'consistency',
      title: 'Consistency Champion',
      description: 'Logged 5+ days this week',
      earned: weekProgress.dailyLogs.completed >= 5,
      icon: '🏆',
    },
    {
      id: 'journaling',
      title: 'Mindful Writer',
      description: 'Written 10+ journal entries',
      earned: journalEntries.length >= 10,
      icon: '📝',
    },
    {
      id: 'recovery',
      title: 'Recovery Warrior',
      description: 'Tracking for 2+ weeks',
      earned: dailyEntries.length >= 14,
      icon: '💪',
    },
    {
      id: 'wellness',
      title: 'Wellness Focus',
      description: 'Good mood 3+ days this week',
      earned: last7Days.filter(d => getMoodScore(d.mood) >= 4).length >= 3,
      icon: '🌟',
    },
  ];

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <TrendingUp className="h-5 w-5 text-gray-600" />
          <h1 className="text-lg font-medium">Progress Dashboard</h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Weekly Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>This Week's Overview</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <ProgressRing
                  value={weekProgress.dailyLogs.completed}
                  max={weekProgress.dailyLogs.total}
                  size={80}
                  color="hsl(var(--soft-pink))"
                  className="mx-auto mb-2"
                >
                  <span className="text-sm font-medium text-gray-700">
                    {weekProgress.dailyLogs.completed}/{weekProgress.dailyLogs.total}
                  </span>
                </ProgressRing>
                <p className="text-xs text-gray-600 font-medium">Daily Logs</p>
                <p className="text-xs text-gray-500">
                  {Math.round((weekProgress.dailyLogs.completed / weekProgress.dailyLogs.total) * 100)}% complete
                </p>
              </div>
              
              <div className="text-center">
                <ProgressRing
                  value={weekProgress.selfCare.completed}
                  max={weekProgress.selfCare.total}
                  size={80}
                  color="hsl(var(--soft-blue))"
                  className="mx-auto mb-2"
                >
                  <span className="text-sm font-medium text-gray-700">
                    {weekProgress.selfCare.completed}/{weekProgress.selfCare.total}
                  </span>
                </ProgressRing>
                <p className="text-xs text-gray-600 font-medium">Self-care</p>
                <p className="text-xs text-gray-500">
                  {Math.round((weekProgress.selfCare.completed / weekProgress.selfCare.total) * 100)}% complete
                </p>
              </div>
              
              <div className="text-center">
                <ProgressRing
                  value={weekProgress.wellness.completed}
                  max={weekProgress.wellness.total}
                  size={80}
                  color="hsl(var(--soft-lavender))"
                  className="mx-auto mb-2"
                >
                  <span className="text-sm font-medium text-gray-700">
                    {weekProgress.wellness.completed}/{weekProgress.wellness.total}
                  </span>
                </ProgressRing>
                <p className="text-xs text-gray-600 font-medium">Wellness</p>
                <p className="text-xs text-gray-500">
                  {Math.round((weekProgress.wellness.completed / weekProgress.wellness.total) * 100)}% complete
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 7-Day Trends */}
        <Card>
          <CardHeader>
            <CardTitle>7-Day Trends</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Mood Trend */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">😊 Average Mood</span>
                <span className="text-sm text-soft-pink font-medium">
                  {averageMood.toFixed(1)}/5
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="soft-pink h-2 rounded-full transition-all duration-500"
                  style={{ width: `${(averageMood / 5) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Pain Trend */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">💪 Average Pain</span>
                <span className="text-sm text-soft-blue font-medium">
                  {averagePain.toFixed(1)}/10
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="soft-blue h-2 rounded-full transition-all duration-500"
                  style={{ width: `${(averagePain / 10) * 100}%` }}
                ></div>
              </div>
            </div>

            {/* Sleep Trend */}
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">😴 Average Sleep</span>
                <span className="text-sm text-soft-lavender font-medium">
                  {averageSleep.toFixed(1)}/4
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="soft-lavender h-2 rounded-full transition-all duration-500"
                  style={{ width: `${(averageSleep / 4) * 100}%` }}
                ></div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Daily Progress Calendar */}
        <Card>
          <CardHeader>
            <CardTitle>Daily Progress This Week</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-1">
              {weekDays.map((day) => {
                const dateStr = format(day, 'yyyy-MM-dd');
                const entry = dailyEntries.find(e => e.date === dateStr);
                const hasEntry = !!entry;
                
                return (
                  <div key={dateStr} className="text-center">
                    <div className="text-xs text-gray-500 mb-1">
                      {format(day, 'EEE')}
                    </div>
                    <div className="text-xs text-gray-400 mb-1">
                      {format(day, 'd')}
                    </div>
                    <div 
                      className={`w-6 h-6 rounded-full mx-auto flex items-center justify-center text-xs ${
                        hasEntry 
                          ? 'soft-pink text-white' 
                          : 'bg-gray-100 text-gray-400'
                      }`}
                    >
                      {hasEntry ? '✓' : '○'}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Achievements */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Award className="h-5 w-5" />
              <span>Achievements</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {achievements.map((achievement) => (
                <div
                  key={achievement.id}
                  className={`p-3 rounded-xl border-2 transition-all ${
                    achievement.earned
                      ? 'warm-yellow-light border-yellow-300'
                      : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="text-center">
                    <div className={`text-2xl mb-1 ${
                      achievement.earned ? '' : 'grayscale opacity-50'
                    }`}>
                      {achievement.icon}
                    </div>
                    <h4 className={`text-xs font-medium ${
                      achievement.earned ? 'text-gray-800' : 'text-gray-500'
                    }`}>
                      {achievement.title}
                    </h4>
                    <p className={`text-xs mt-1 ${
                      achievement.earned ? 'text-gray-600' : 'text-gray-400'
                    }`}>
                      {achievement.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Summary Stats */}
        <Card className="soft-lavender-light border-soft-lavender">
          <CardContent className="p-4">
            <div className="text-center">
              <h3 className="font-medium text-gray-800 mb-2">Recovery Summary</h3>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-soft-pink">
                    {dailyEntries.length}
                  </div>
                  <div className="text-xs text-gray-600">Total Logs</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-soft-blue">
                    {journalEntries.length}
                  </div>
                  <div className="text-xs text-gray-600">Journal Entries</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-soft-lavender">
                    {achievements.filter(a => a.earned).length}
                  </div>
                  <div className="text-xs text-gray-600">Achievements</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Motivational Message */}
        <Card className="calm-green-light border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="text-2xl">🌟</div>
              <div>
                <p className="font-medium text-gray-800">Keep up the great work!</p>
                <p className="text-sm text-gray-600">
                  Every day of tracking is a step forward in your recovery journey.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
