import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { EMERGENCY_CONTACTS, EMERGENCY_GUIDES } from "@/lib/constants";
import { ArrowLeft, Phone, AlertTriangle, ChevronDown, ExternalLink } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function Emergency() {
  const [, setLocation] = useLocation();
  const [openGuides, setOpenGuides] = useState<Set<string>>(new Set());

  const toggleGuide = (guideId: string) => {
    const newOpenGuides = new Set(openGuides);
    if (newOpenGuides.has(guideId)) {
      newOpenGuides.delete(guideId);
    } else {
      newOpenGuides.add(guideId);
    }
    setOpenGuides(newOpenGuides);
  };

  const handleCall = (number: string) => {
    if (number === "Emergency") {
      window.open('tel:911', '_self');
    } else if (number.startsWith('1-')) {
      window.open(`tel:${number}`, '_self');
    } else {
      // For placeholder numbers, show alert
      alert(`Call your ${number.toLowerCase()}. Please add their number to your contacts.`);
    }
  };

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <AlertTriangle className="h-5 w-5 text-red-600" />
          <h1 className="text-lg font-medium">Emergency Resources</h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Emergency Alert */}
        <Card className="gentle-coral-light border-red-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="h-6 w-6 text-red-600 mt-0.5" />
              <div>
                <p className="font-medium text-red-800 mb-2">In case of emergency, call 911 immediately</p>
                <p className="text-sm text-red-700">
                  Trust your instincts. If something feels wrong, don't hesitate to seek medical help.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Phone className="h-5 w-5" />
              <span>Emergency Contacts</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {EMERGENCY_CONTACTS.map((contact) => (
              <div key={contact.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-800">{contact.name}</h4>
                  <p className="text-sm text-gray-600">{contact.description}</p>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleCall(contact.number)}
                  className={`${
                    contact.number === "Emergency" 
                      ? "bg-red-600 hover:bg-red-700" 
                      : "bg-soft-blue hover:bg-soft-blue/90"
                  } text-white`}
                >
                  <Phone className="h-4 w-4 mr-1" />
                  Call
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Emergency Decision Helper */}
        <Card>
          <CardHeader>
            <CardTitle>Should I Call the Doctor?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <p className="text-sm text-gray-700 mb-3">
                Call your healthcare provider immediately if you experience:
              </p>
              
              <div className="space-y-2">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                  <p className="text-sm text-gray-700">Heavy bleeding (soaking through a pad every hour)</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                  <p className="text-sm text-gray-700">Fever over 100.4°F (38°C)</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                  <p className="text-sm text-gray-700">Severe abdominal or pelvic pain</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                  <p className="text-sm text-gray-700">Signs of infection (foul-smelling discharge, increased pain)</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                  <p className="text-sm text-gray-700">Thoughts of harming yourself or your baby</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                  <p className="text-sm text-gray-700">Difficulty breathing or chest pain</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Guides */}
        <Card>
          <CardHeader>
            <CardTitle>Emergency Guides</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {EMERGENCY_GUIDES.map((guide) => {
              const isOpen = openGuides.has(guide.id);
              
              return (
                <Collapsible key={guide.id} open={isOpen} onOpenChange={() => toggleGuide(guide.id)}>
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-between p-4 h-auto text-left"
                    >
                      <span className="font-medium">{guide.title}</span>
                      <ChevronDown 
                        className={`h-4 w-4 transition-transform ${isOpen ? 'transform rotate-180' : ''}`} 
                      />
                    </Button>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="mt-2">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-700 leading-relaxed">
                        {guide.content}
                      </p>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              );
            })}
          </CardContent>
        </Card>

        {/* Baby Emergency Signs */}
        <Card className="warm-yellow-light border-yellow-200">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>👶</span>
              <span>Baby Emergency Signs</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-700 mb-3">
              For babies under 3 months, call your pediatrician immediately for:
            </p>
            <div className="space-y-2">
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                <p className="text-sm text-gray-700">Any fever over 100.4°F (38°C)</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                <p className="text-sm text-gray-700">Difficulty breathing or unusual breathing patterns</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                <p className="text-sm text-gray-700">Unusual sleepiness or difficulty waking</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                <p className="text-sm text-gray-700">Refusing to eat for several feedings</p>
              </div>
              <div className="flex items-start space-x-2">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                <p className="text-sm text-gray-700">Persistent crying that won't stop</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Mental Health Resources */}
        <Card className="soft-lavender-light border-soft-lavender">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>💜</span>
              <span>Mental Health Support</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                <div>
                  <h4 className="font-medium text-gray-800">Postpartum Support International</h4>
                  <p className="text-sm text-gray-600">24/7 helpline for postpartum support</p>
                </div>
                <Button
                  size="sm"
                  onClick={() => handleCall("1-800-944-4773")}
                  className="bg-soft-lavender hover:bg-soft-lavender/90"
                >
                  <Phone className="h-4 w-4 mr-1" />
                  Call
                </Button>
              </div>
              
              <div className="flex items-center justify-between p-3 bg-white rounded-lg">
                <div>
                  <h4 className="font-medium text-gray-800">Crisis Text Line</h4>
                  <p className="text-sm text-gray-600">Text HOME to 741741</p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => window.open('sms:741741?body=HOME', '_self')}
                >
                  <span className="text-sm mr-1">💬</span>
                  Text
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Important Note */}
        <Card className="calm-green-light border-green-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="text-xl">ℹ️</div>
              <div>
                <p className="font-medium text-gray-800 mb-1">Remember</p>
                <p className="text-sm text-gray-600">
                  You know your body and your baby best. If something doesn't feel right, 
                  trust your instincts and seek help. It's always better to be safe.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
