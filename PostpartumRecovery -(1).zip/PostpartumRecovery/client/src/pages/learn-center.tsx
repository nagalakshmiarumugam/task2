import { useState } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { LEARN_ARTICLES } from "@/lib/constants";
import { ArrowLeft, Search, BookOpen, Clock, ChevronDown } from "lucide-react";
import { useLocation } from "wouter";

export default function LearnCenter() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [openArticles, setOpenArticles] = useState<Set<string>>(new Set());

  const categories = [
    { value: "all", label: "All Articles", color: "bg-gray-100" },
    { value: "breastfeeding", label: "Breastfeeding", color: "bg-soft-pink" },
    { value: "depression", label: "Mental Health", color: "bg-soft-blue" },
    { value: "recovery", label: "Recovery", color: "bg-soft-lavender" },
    { value: "bonding", label: "Baby Bonding", color: "bg-calm-green" },
    { value: "self-care", label: "Self-Care", color: "bg-warm-yellow" },
  ];

  const filteredArticles = LEARN_ARTICLES.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || article.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleArticle = (articleId: string) => {
    const newOpenArticles = new Set(openArticles);
    if (newOpenArticles.has(articleId)) {
      newOpenArticles.delete(articleId);
    } else {
      newOpenArticles.add(articleId);
    }
    setOpenArticles(newOpenArticles);
  };

  const getCategoryInfo = (category: string) => {
    return categories.find(c => c.value === category) || categories[0];
  };

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <BookOpen className="h-5 w-5 text-gray-600" />
          <h1 className="text-lg font-medium">Learn Center</h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search articles..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category.value}
              variant={selectedCategory === category.value ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.value)}
              className={`flex-shrink-0 ${
                selectedCategory === category.value 
                  ? "bg-soft-pink hover:bg-soft-pink/90" 
                  : ""
              }`}
            >
              {category.label}
            </Button>
          ))}
        </div>

        {/* Articles Count */}
        <div className="text-sm text-gray-600">
          {filteredArticles.length} article{filteredArticles.length !== 1 ? 's' : ''} found
        </div>

        {/* Articles List */}
        <div className="space-y-3">
          {filteredArticles.map((article) => {
            const categoryInfo = getCategoryInfo(article.category);
            const isOpen = openArticles.has(article.id);
            
            return (
              <Card key={article.id}>
                <Collapsible
                  open={isOpen}
                  onOpenChange={() => toggleArticle(article.id)}
                >
                  <CollapsibleTrigger asChild>
                    <CardHeader className="cursor-pointer hover:bg-gray-50/50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge 
                              className={`${categoryInfo.color} text-gray-700 text-xs`}
                              variant="secondary"
                            >
                              {categoryInfo.label}
                            </Badge>
                            <div className="flex items-center text-xs text-gray-500">
                              <Clock className="h-3 w-3 mr-1" />
                              {article.readTime} min read
                            </div>
                          </div>
                          <CardTitle className="text-left text-base">
                            {article.title}
                          </CardTitle>
                        </div>
                        <ChevronDown 
                          className={`h-5 w-5 text-gray-400 transition-transform ${
                            isOpen ? 'transform rotate-180' : ''
                          }`} 
                        />
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  
                  <CollapsibleContent>
                    <CardContent className="pt-0">
                      <div className="prose prose-sm max-w-none">
                        <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                          {article.content}
                        </p>
                      </div>
                      
                      {/* Article Footer */}
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>Tap to collapse</span>
                          <span>Article #{article.id}</span>
                        </div>
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Collapsible>
              </Card>
            );
          })}
        </div>

        {/* No Results */}
        {filteredArticles.length === 0 && (
          <Card>
            <CardContent className="text-center py-8">
              <div className="text-4xl mb-2">📚</div>
              <h3 className="font-medium text-gray-800 mb-1">No articles found</h3>
              <p className="text-sm text-gray-600">
                Try adjusting your search terms or category filter
              </p>
            </CardContent>
          </Card>
        )}

        {/* Learning Tips */}
        <Card className="soft-lavender-light border-soft-lavender">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="text-xl">💡</div>
              <div>
                <h3 className="font-medium text-gray-800 mb-2">Learning Tips</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Take your time - recovery is a journey, not a race</li>
                  <li>• Bookmark important articles for quick reference</li>
                  <li>• Discuss what you learn with your healthcare provider</li>
                  <li>• Remember that every experience is unique</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support Message */}
        <Card className="warm-yellow-light border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="text-2xl">🤗</div>
              <div>
                <p className="font-medium text-gray-800">You're doing great!</p>
                <p className="text-sm text-gray-600">
                  Learning about postpartum recovery shows how much you care about your wellbeing.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
