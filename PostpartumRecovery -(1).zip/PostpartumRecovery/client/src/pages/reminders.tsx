import { useState, useEffect } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { Reminder } from "@shared/schema";
import { REMINDER_TYPES } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Plus, Bell, Clock } from "lucide-react";
import { useLocation } from "wouter";

export default function Reminders() {
  const [, setLocation] = useLocation();
  const { reminders, updateReminder, getActiveReminders } = useRecoveryData();
  const { toast } = useToast();
  
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newReminderType, setNewReminderType] = useState<string>("");
  const [customTitle, setCustomTitle] = useState("");
  const [customDescription, setCustomDescription] = useState("");
  const [customFrequency, setCustomFrequency] = useState("");

  // Initialize default reminders if none exist
  useEffect(() => {
    if (reminders.length === 0) {
      REMINDER_TYPES.forEach((reminder, index) => {
        const defaultReminder: Reminder = {
          id: `reminder_${index}`,
          type: reminder.type as any,
          title: reminder.title,
          description: reminder.description,
          frequency: reminder.frequency,
          enabled: true,
        };
        updateReminder(defaultReminder.id, defaultReminder);
      });
    }
  }, [reminders.length, updateReminder]);

  const handleToggleReminder = (id: string, enabled: boolean) => {
    updateReminder(id, { enabled });
    
    if (enabled && 'Notification' in window) {
      Notification.requestPermission().then(permission => {
        if (permission === 'granted') {
          toast({
            title: "Reminder enabled",
            description: "You'll receive notifications for this reminder.",
          });
        } else {
          toast({
            title: "Enable notifications",
            description: "Please allow notifications in your browser settings.",
            variant: "destructive",
          });
        }
      });
    }
  };

  const handleAddCustomReminder = () => {
    if (!customTitle.trim()) {
      toast({
        title: "Error",
        description: "Please enter a title for your reminder.",
        variant: "destructive",
      });
      return;
    }

    const newReminder: Reminder = {
      id: `custom_${Date.now()}`,
      type: "custom",
      title: customTitle,
      description: customDescription || "Custom reminder",
      frequency: customFrequency || "daily",
      enabled: true,
    };

    updateReminder(newReminder.id, newReminder);
    
    toast({
      title: "Reminder added",
      description: "Your custom reminder has been created.",
    });

    setShowAddDialog(false);
    setCustomTitle("");
    setCustomDescription("");
    setCustomFrequency("");
  };

  const getReminderIcon = (type: string) => {
    const reminderType = REMINDER_TYPES.find(r => r.type === type);
    return reminderType?.icon || "⏰";
  };

  const getFrequencyText = (frequency: string) => {
    switch (frequency) {
      case "every-3-hours": return "Every 3 hours";
      case "3-times-daily": return "3 times daily";
      case "twice-daily": return "Twice daily";
      case "daily": return "Daily";
      case "weekly": return "Weekly";
      default: return frequency;
    }
  };

  const activeReminders = getActiveReminders();

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center space-x-2">
            <Bell className="h-5 w-5 text-gray-600" />
            <h1 className="text-lg font-medium">Self-Care Reminders</h1>
          </div>
        </div>
        
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-soft-pink hover:bg-soft-pink/90">
              <Plus className="h-4 w-4 mr-1" />
              Add
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Custom Reminder</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Take vitamins"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Optional description..."
                  value={customDescription}
                  onChange={(e) => setCustomDescription(e.target.value)}
                  rows={2}
                />
              </div>
              <div>
                <Label htmlFor="frequency">Frequency</Label>
                <Select value={customFrequency} onValueChange={setCustomFrequency}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="twice-daily">Twice daily</SelectItem>
                    <SelectItem value="3-times-daily">3 times daily</SelectItem>
                    <SelectItem value="every-3-hours">Every 3 hours</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" onClick={() => setShowAddDialog(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleAddCustomReminder} className="flex-1">
                  Add Reminder
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Active Reminders Summary */}
        {activeReminders.length > 0 && (
          <Card className="soft-blue-light border-soft-blue">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="text-2xl">✅</div>
                <div>
                  <p className="font-medium text-gray-800">
                    {activeReminders.length} active reminder{activeReminders.length !== 1 ? 's' : ''}
                  </p>
                  <p className="text-sm text-gray-600">
                    We'll help you stay on track with your self-care
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Reminders List */}
        <div className="space-y-3">
          {reminders.map((reminder) => (
            <Card key={reminder.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 flex-1">
                    <div className="text-2xl">
                      {getReminderIcon(reminder.type)}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-800">{reminder.title}</h3>
                      <p className="text-sm text-gray-600">{reminder.description}</p>
                      <div className="flex items-center space-x-1 mt-1">
                        <Clock className="h-3 w-3 text-gray-400" />
                        <span className="text-xs text-gray-500">
                          {getFrequencyText(reminder.frequency)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Switch
                    checked={reminder.enabled}
                    onCheckedChange={(enabled) => handleToggleReminder(reminder.id, enabled)}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Notification Settings Info */}
        <Card className="warm-yellow-light border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="text-xl">ℹ️</div>
              <div>
                <h3 className="font-medium text-gray-800 mb-1">About Notifications</h3>
                <p className="text-sm text-gray-600">
                  Reminders work best when you allow notifications in your browser. 
                  Make sure to keep this tab open or add this app to your home screen for the best experience.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tips for Self-Care */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>💡</span>
              <span>Self-Care Tips</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start space-x-3">
              <div className="text-lg">💧</div>
              <div>
                <p className="text-sm font-medium">Stay Hydrated</p>
                <p className="text-xs text-gray-600">Aim for 8-10 glasses of water daily, especially if breastfeeding</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="text-lg">🍎</div>
              <div>
                <p className="text-sm font-medium">Eat Regularly</p>
                <p className="text-xs text-gray-600">Don't skip meals - your body needs energy to heal</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <div className="text-lg">💪</div>
              <div>
                <p className="text-sm font-medium">Gentle Movement</p>
                <p className="text-xs text-gray-600">Light stretching and Kegel exercises support recovery</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
