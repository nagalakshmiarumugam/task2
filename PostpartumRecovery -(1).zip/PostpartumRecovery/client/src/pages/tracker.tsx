import { useState } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MoodSelector } from "@/components/ui/mood-selector";
import { PainSlider } from "@/components/ui/pain-slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { DailyEntry } from "@shared/schema";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Calendar } from "lucide-react";
import { useLocation } from "wouter";

export default function Tracker() {
  const [, setLocation] = useLocation();
  const { addOrUpdateDailyEntry, getTodayEntry } = useRecoveryData();
  const { toast } = useToast();
  
  const todayEntry = getTodayEntry();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form state
  const [mood, setMood] = useState(todayEntry?.mood.mood || "neutral");
  const [moodNotes, setMoodNotes] = useState(todayEntry?.mood.notes || "");
  const [painLevel, setPainLevel] = useState(todayEntry?.pain.level || 0);
  const [painLocation, setPainLocation] = useState(todayEntry?.pain.location || "");
  const [painNotes, setPainNotes] = useState(todayEntry?.pain.notes || "");
  const [sleepQuality, setSleepQuality] = useState(todayEntry?.sleep.quality || "fair");
  const [sleepHours, setSleepHours] = useState(todayEntry?.sleep.hours || 0);
  const [sleepNotes, setSleepNotes] = useState(todayEntry?.sleep.notes || "");
  const [diaper, setDiaper] = useState(todayEntry?.babyCare.diaper || false);
  const [feeding, setFeeding] = useState(todayEntry?.babyCare.feeding || false);
  const [bath, setBath] = useState(todayEntry?.babyCare.bath || false);

  const handleSave = async () => {
    setIsSubmitting(true);
    
    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      const entry: DailyEntry = {
        id: todayEntry?.id || `daily_${Date.now()}`,
        date: today,
        mood: {
          mood: mood as any,
          emoji: "",
          notes: moodNotes,
        },
        pain: {
          level: painLevel,
          location: painLocation,
          notes: painNotes,
        },
        sleep: {
          quality: sleepQuality as any,
          hours: sleepHours || undefined,
          notes: sleepNotes,
        },
        babyCare: {
          diaper,
          feeding,
          bath,
        },
        createdAt: new Date().toISOString(),
      };

      addOrUpdateDailyEntry(entry);
      
      toast({
        title: "Entry saved!",
        description: "Your daily tracker entry has been saved.",
      });
      
      setLocation('/');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save your entry. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <Calendar className="h-5 w-5 text-gray-600" />
          <h1 className="text-lg font-medium">Daily Tracker</h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Date Display */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-center text-lg">
              Today - {format(new Date(), 'EEEE, MMMM d, yyyy')}
            </CardTitle>
          </CardHeader>
        </Card>

        {/* Mood Tracking */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>😊</span>
              <span>Mood Tracking</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm text-gray-600 mb-3">How are you feeling today?</label>
              <MoodSelector value={mood} onChange={setMood} />
            </div>
            <div>
              <label className="block text-sm text-gray-600 mb-2">Notes (optional)</label>
              <Textarea
                placeholder="Describe how you're feeling..."
                value={moodNotes}
                onChange={(e) => setMoodNotes(e.target.value)}
                className="resize-none"
                rows={2}
              />
            </div>
          </CardContent>
        </Card>

        {/* Pain Tracking */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>💪</span>
              <span>Pain Level</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <PainSlider value={painLevel} onChange={setPainLevel} />
            
            <div>
              <label className="block text-sm text-gray-600 mb-2">Pain location (optional)</label>
              <Select value={painLocation} onValueChange={setPainLocation}>
                <SelectTrigger>
                  <SelectValue placeholder="Select location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="abdomen">Abdomen</SelectItem>
                  <SelectItem value="back">Back</SelectItem>
                  <SelectItem value="breasts">Breasts</SelectItem>
                  <SelectItem value="perineum">Perineum</SelectItem>
                  <SelectItem value="incision">C-section incision</SelectItem>
                  <SelectItem value="headache">Headache</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm text-gray-600 mb-2">Pain notes (optional)</label>
              <Textarea
                placeholder="Describe your pain..."
                value={painNotes}
                onChange={(e) => setPainNotes(e.target.value)}
                className="resize-none"
                rows={2}
              />
            </div>
          </CardContent>
        </Card>

        {/* Sleep Tracking */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>😴</span>
              <span>Sleep Quality</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm text-gray-600 mb-2">How did you sleep?</label>
              <Select value={sleepQuality} onValueChange={setSleepQuality}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="poor">Poor</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="excellent">Excellent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm text-gray-600 mb-2">Hours of sleep (optional)</label>
              <Select value={sleepHours.toString()} onValueChange={(value) => setSleepHours(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue placeholder="Select hours" />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({length: 13}, (_, i) => (
                    <SelectItem key={i} value={i.toString()}>{i} hours</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm text-gray-600 mb-2">Sleep notes (optional)</label>
              <Textarea
                placeholder="How was your sleep? Any interruptions?"
                value={sleepNotes}
                onChange={(e) => setSleepNotes(e.target.value)}
                className="resize-none"
                rows={2}
              />
            </div>
          </CardContent>
        </Card>

        {/* Baby Care Checklist */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>👶</span>
              <span>Baby Care Today</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="diaper" 
                  checked={diaper} 
                  onCheckedChange={setDiaper}
                />
                <label htmlFor="diaper" className="text-sm font-medium">Changed diapers</label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="feeding" 
                  checked={feeding} 
                  onCheckedChange={setFeeding}
                />
                <label htmlFor="feeding" className="text-sm font-medium">Fed baby</label>
              </div>
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="bath" 
                  checked={bath} 
                  onCheckedChange={setBath}
                />
                <label htmlFor="bath" className="text-sm font-medium">Bath time</label>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <Button
          className="w-full bg-gradient-to-r from-soft-pink to-soft-lavender hover:opacity-90 h-12 text-lg font-medium"
          onClick={handleSave}
          disabled={isSubmitting}
        >
          {isSubmitting ? "Saving..." : "Save Today's Entry"}
        </Button>
      </div>
    </>
  );
}
