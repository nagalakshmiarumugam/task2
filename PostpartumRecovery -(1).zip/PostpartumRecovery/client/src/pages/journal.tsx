import { useState } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { JournalEntry } from "@shared/schema";
import { MOOD_OPTIONS } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ArrowLeft, Plus, BookOpen, Mic, Search, Trash2 } from "lucide-react";
import { useLocation } from "wouter";

export default function Journal() {
  const [, setLocation] = useLocation();
  const { journalEntries, addJournalEntry, deleteJournalEntry } = useRecoveryData();
  const { toast } = useToast();
  
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [entryType, setEntryType] = useState<"text" | "voice">("text");
  const [content, setContent] = useState("");
  const [mood, setMood] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);

  const filteredEntries = journalEntries.filter(entry =>
    entry.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (entry.mood && entry.mood.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleAddEntry = () => {
    if (!content.trim()) {
      toast({
        title: "Error",
        description: "Please enter some content for your journal entry.",
        variant: "destructive",
      });
      return;
    }

    const newEntry: JournalEntry = {
      id: `journal_${Date.now()}`,
      date: format(new Date(), 'yyyy-MM-dd'),
      type: entryType,
      content: content.trim(),
      mood: mood || undefined,
      createdAt: new Date().toISOString(),
    };

    addJournalEntry(newEntry);
    
    toast({
      title: "Entry added",
      description: "Your journal entry has been saved.",
    });

    setShowAddDialog(false);
    setContent("");
    setMood("");
  };

  const handleDeleteEntry = (id: string) => {
    deleteJournalEntry(id);
    toast({
      title: "Entry deleted",
      description: "Your journal entry has been removed.",
    });
  };

  const startVoiceRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        const audioUrl = URL.createObjectURL(blob);
        setContent(`Voice recording saved (${new Date().toLocaleTimeString()})`);
        // In a real app, you'd save the audio blob to local storage or IndexedDB
      };

      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
      
      toast({
        title: "Recording started",
        description: "Speak your thoughts...",
      });
    } catch (error) {
      toast({
        title: "Recording failed",
        description: "Could not access microphone. Please check permissions.",
        variant: "destructive",
      });
    }
  };

  const stopVoiceRecording = () => {
    if (mediaRecorder) {
      mediaRecorder.stop();
      mediaRecorder.stream.getTracks().forEach(track => track.stop());
      setMediaRecorder(null);
      setIsRecording(false);
    }
  };

  const getMoodEmoji = (moodValue?: string) => {
    return MOOD_OPTIONS.find(m => m.value === moodValue)?.emoji || "";
  };

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-gray-600" />
            <h1 className="text-lg font-medium">Journal</h1>
          </div>
        </div>
        
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button size="sm" className="bg-soft-pink hover:bg-soft-pink/90">
              <Plus className="h-4 w-4 mr-1" />
              New Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>New Journal Entry</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {/* Entry Type Selection */}
              <div>
                <label className="block text-sm text-gray-600 mb-2">Entry Type</label>
                <div className="flex space-x-2">
                  <Button
                    variant={entryType === "text" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setEntryType("text")}
                    className="flex-1"
                  >
                    📝 Text
                  </Button>
                  <Button
                    variant={entryType === "voice" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setEntryType("voice")}
                    className="flex-1"
                  >
                    🎙️ Voice
                  </Button>
                </div>
              </div>

              {/* Mood Selection */}
              <div>
                <label className="block text-sm text-gray-600 mb-2">Mood (optional)</label>
                <Select value={mood} onValueChange={setMood}>
                  <SelectTrigger>
                    <SelectValue placeholder="How are you feeling?" />
                  </SelectTrigger>
                  <SelectContent>
                    {MOOD_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.emoji} {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Content Input */}
              {entryType === "text" ? (
                <div>
                  <label className="block text-sm text-gray-600 mb-2">Your thoughts</label>
                  <Textarea
                    placeholder="What's on your mind today?"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="resize-none min-h-[120px]"
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-sm text-gray-600 mb-2">Voice Recording</label>
                  <div className="flex flex-col space-y-2">
                    {!isRecording ? (
                      <Button
                        variant="outline"
                        onClick={startVoiceRecording}
                        className="flex items-center space-x-2"
                      >
                        <Mic className="h-4 w-4" />
                        <span>Start Recording</span>
                      </Button>
                    ) : (
                      <Button
                        variant="destructive"
                        onClick={stopVoiceRecording}
                        className="flex items-center space-x-2 animate-pulse"
                      >
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span>Stop Recording</span>
                      </Button>
                    )}
                    {content && (
                      <p className="text-sm text-gray-600">{content}</p>
                    )}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setShowAddDialog(false)} 
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleAddEntry} 
                  className="flex-1"
                  disabled={!content.trim()}
                >
                  Save Entry
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search your entries..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Entries Summary */}
        {journalEntries.length > 0 && (
          <Card className="soft-blue-light border-soft-blue">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="text-2xl">📖</div>
                <div>
                  <p className="font-medium text-gray-800">
                    {journalEntries.length} journal entr{journalEntries.length !== 1 ? 'ies' : 'y'}
                  </p>
                  <p className="text-sm text-gray-600">
                    Your thoughts and feelings over time
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Journal Entries */}
        {filteredEntries.length > 0 ? (
          <div className="space-y-3">
            {filteredEntries.map((entry) => (
              <Card key={entry.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary" className="text-xs">
                        {entry.type === "text" ? "📝 Text" : "🎙️ Voice"}
                      </Badge>
                      {entry.mood && (
                        <Badge variant="outline" className="text-xs">
                          {getMoodEmoji(entry.mood)} {MOOD_OPTIONS.find(m => m.value === entry.mood)?.label}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-gray-500">
                        {format(new Date(entry.createdAt), 'MMM d, yyyy')}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-gray-400 hover:text-red-500"
                        onClick={() => handleDeleteEntry(entry.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-700 whitespace-pre-wrap leading-relaxed">
                    {entry.content}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : journalEntries.length === 0 ? (
          // Empty state
          <Card>
            <CardContent className="text-center py-12">
              <div className="text-6xl mb-4">📝</div>
              <h3 className="font-medium text-gray-800 mb-2">Start Your Journal</h3>
              <p className="text-sm text-gray-600 mb-4">
                Express your thoughts and feelings during this special time
              </p>
              <Button 
                onClick={() => setShowAddDialog(true)}
                className="bg-soft-pink hover:bg-soft-pink/90"
              >
                <Plus className="h-4 w-4 mr-2" />
                Write Your First Entry
              </Button>
            </CardContent>
          </Card>
        ) : (
          // No search results
          <Card>
            <CardContent className="text-center py-8">
              <div className="text-4xl mb-2">🔍</div>
              <h3 className="font-medium text-gray-800 mb-1">No entries found</h3>
              <p className="text-sm text-gray-600">
                Try adjusting your search terms
              </p>
            </CardContent>
          </Card>
        )}

        {/* Journaling Tips */}
        <Card className="soft-lavender-light border-soft-lavender">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <div className="text-xl">💡</div>
              <div>
                <h3 className="font-medium text-gray-800 mb-2">Journaling Tips</h3>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Write freely without worrying about grammar</li>
                  <li>• Include both challenges and victories</li>
                  <li>• Use voice entries when you're too tired to type</li>
                  <li>• Review past entries to see your progress</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
