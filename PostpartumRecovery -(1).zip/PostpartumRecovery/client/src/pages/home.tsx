import { useState } from "react";
import { useLocation } from "wouter";
import { AppHeader } from "@/components/layout/app-header";
import { ProgressRing } from "@/components/ui/progress-ring";
import { Button } from "@/components/ui/button";
import { QuickLogModal } from "@/components/modals/quick-log-modal";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { MOOD_OPTIONS, SLEEP_QUALITY_OPTIONS } from "@/lib/constants";
import { Plus } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const [showQuickLog, setShowQuickLog] = useState(false);
  const { 
    userProfile, 
    getTodayEntry, 
    getWeeklyProgress, 
    journalEntries, 
    memoryNotes,
    babyProfile 
  } = useRecoveryData();

  const todayEntry = getTodayEntry();
  const weekProgress = getWeeklyProgress();

  const getMoodEmoji = (mood?: string) => {
    return MOOD_OPTIONS.find(m => m.value === mood)?.emoji || "😐";
  };

  const getSleepColor = (quality?: string) => {
    return SLEEP_QUALITY_OPTIONS.find(s => s.value === quality)?.color || "text-gray-500";
  };

  const getLastJournalTime = () => {
    if (journalEntries.length === 0) return "Never";
    const lastEntry = journalEntries[0];
    const date = new Date(lastEntry.createdAt);
    const now = new Date();
    const diffHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  const getLastFeedTime = () => {
    if (!babyProfile?.feedingLogs.length) return "No data";
    const lastFeed = babyProfile.feedingLogs[0];
    const date = new Date(lastFeed.time);
    const now = new Date();
    const diffHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  return (
    <>
      <AppHeader />
      
      {/* Welcome Message */}
      <div className="px-4 py-4 bg-gradient-to-r from-soft-blue-light to-soft-lavender-light">
        <div className="flex items-center space-x-3">
          <div className="text-2xl">🌸</div>
          <div>
            <p className="text-gray-700 font-medium">
              Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, {userProfile?.name || 'Mumma'}
            </p>
            <p className="text-sm text-gray-600">How are you feeling today?</p>
          </div>
        </div>
      </div>

      {/* Today's Quick Check-in */}
      <div className="px-4 py-4">
        <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
          <h3 className="font-medium text-gray-800 mb-3">Today's Quick Check-in</h3>
          <div className="grid grid-cols-3 gap-3">
            <button 
              className="flex flex-col items-center p-3 soft-pink-light rounded-xl border-2 border-transparent hover:border-soft-pink transition-colors touch-target"
              onClick={() => setShowQuickLog(true)}
            >
              <div className="text-2xl mb-1">{getMoodEmoji(todayEntry?.mood.mood)}</div>
              <span className="text-xs text-gray-600">Mood</span>
              <span className="text-xs text-soft-pink font-medium">
                {todayEntry?.mood.mood ? MOOD_OPTIONS.find(m => m.value === todayEntry.mood.mood)?.label : "Not set"}
              </span>
            </button>
            
            <button 
              className="flex flex-col items-center p-3 soft-blue-light rounded-xl border-2 border-transparent hover:border-soft-blue transition-colors touch-target"
              onClick={() => setShowQuickLog(true)}
            >
              <div className="text-2xl mb-1">💪</div>
              <span className="text-xs text-gray-600">Pain</span>
              <span className="text-xs text-soft-blue font-medium">
                {todayEntry?.pain.level !== undefined ? `${todayEntry.pain.level}/10` : "Not set"}
              </span>
            </button>
            
            <button 
              className="flex flex-col items-center p-3 soft-lavender-light rounded-xl border-2 border-transparent hover:border-soft-lavender transition-colors touch-target"
              onClick={() => setShowQuickLog(true)}
            >
              <div className="text-2xl mb-1">😴</div>
              <span className="text-xs text-gray-600">Sleep</span>
              <span className={`text-xs font-medium ${getSleepColor(todayEntry?.sleep.quality)}`}>
                {todayEntry?.sleep.quality ? SLEEP_QUALITY_OPTIONS.find(s => s.value === todayEntry.sleep.quality)?.label : "Not set"}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Features */}
      <div className="px-4 pb-4">
        <h3 className="font-medium text-gray-800 mb-3">Your Recovery Tools</h3>
        <div className="grid grid-cols-2 gap-3">
          
          <Button
            className="bg-gradient-to-br from-soft-pink to-soft-pink/80 hover:from-soft-pink/90 hover:to-soft-pink/70 p-4 rounded-2xl text-white text-left shadow-sm hover:shadow-md transition-shadow min-h-[120px] flex flex-col items-start justify-between"
            onClick={() => setLocation('/tracker')}
          >
            <div className="text-2xl mb-2">📅</div>
            <div>
              <h4 className="font-medium mb-1">Daily Tracker</h4>
              <p className="text-sm opacity-90">Log your progress</p>
              <div className="mt-2 text-xs opacity-80">
                {todayEntry ? "Logged today" : "Not logged today"}
              </div>
            </div>
          </Button>

          <Button
            className="bg-gradient-to-br from-soft-blue to-soft-blue/80 hover:from-soft-blue/90 hover:to-soft-blue/70 p-4 rounded-2xl text-white text-left shadow-sm hover:shadow-md transition-shadow min-h-[120px] flex flex-col items-start justify-between"
            onClick={() => setLocation('/reminders')}
          >
            <div className="text-2xl mb-2">⏰</div>
            <div>
              <h4 className="font-medium mb-1">Reminders</h4>
              <p className="text-sm opacity-90">Self-care alerts</p>
              <div className="mt-2 text-xs opacity-80">Next: Drink water</div>
            </div>
          </Button>

          <Button
            className="bg-gradient-to-br from-soft-lavender to-soft-lavender/80 hover:from-soft-lavender/90 hover:to-soft-lavender/70 p-4 rounded-2xl text-white text-left shadow-sm hover:shadow-md transition-shadow min-h-[120px] flex flex-col items-start justify-between"
            onClick={() => setLocation('/learn-center')}
          >
            <div className="text-2xl mb-2">📚</div>
            <div>
              <h4 className="font-medium mb-1">Learn Center</h4>
              <p className="text-sm opacity-90">Recovery guides</p>
              <div className="mt-2 text-xs opacity-80">6 articles available</div>
            </div>
          </Button>

          <Button
            className="bg-gradient-to-br from-calm-green to-calm-green/80 hover:from-calm-green/90 hover:to-calm-green/70 p-4 rounded-2xl text-white text-left shadow-sm hover:shadow-md transition-shadow min-h-[120px] flex flex-col items-start justify-between"
            onClick={() => setLocation('/journal')}
          >
            <div className="text-2xl mb-2">🎙️</div>
            <div>
              <h4 className="font-medium mb-1">Journal</h4>
              <p className="text-sm opacity-90">Voice & text logs</p>
              <div className="mt-2 text-xs opacity-80">{journalEntries.length} entries</div>
            </div>
          </Button>

        </div>
      </div>

      {/* Weekly Progress */}
      <div className="px-4 pb-4">
        <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-medium text-gray-800">This Week's Progress</h3>
            <Button
              variant="ghost"
              className="text-soft-blue text-sm font-medium p-0 h-auto"
              onClick={() => setLocation('/progress')}
            >
              View All
            </Button>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="text-center">
              <ProgressRing
                value={weekProgress.dailyLogs.completed}
                max={weekProgress.dailyLogs.total}
                size={64}
                color="hsl(var(--soft-pink))"
                className="mx-auto mb-2"
              >
                <span className="text-sm font-medium text-gray-700">
                  {weekProgress.dailyLogs.completed}/{weekProgress.dailyLogs.total}
                </span>
              </ProgressRing>
              <p className="text-xs text-gray-600">Daily Logs</p>
            </div>
            
            <div className="text-center">
              <ProgressRing
                value={weekProgress.selfCare.completed}
                max={weekProgress.selfCare.total}
                size={64}
                color="hsl(var(--soft-blue))"
                className="mx-auto mb-2"
              >
                <span className="text-sm font-medium text-gray-700">
                  {weekProgress.selfCare.completed}/{weekProgress.selfCare.total}
                </span>
              </ProgressRing>
              <p className="text-xs text-gray-600">Self-care</p>
            </div>
            
            <div className="text-center">
              <ProgressRing
                value={weekProgress.wellness.completed}
                max={weekProgress.wellness.total}
                size={64}
                color="hsl(var(--soft-lavender))"
                className="mx-auto mb-2"
              >
                <span className="text-sm font-medium text-gray-700">
                  {weekProgress.wellness.completed}/{weekProgress.wellness.total}
                </span>
              </ProgressRing>
              <p className="text-xs text-gray-600">Wellness</p>
            </div>
          </div>

          {/* Achievement Badge */}
          <div className="warm-yellow-light border border-yellow-200 rounded-xl p-3">
            <div className="flex items-center space-x-3">
              <div className="text-2xl">🏆</div>
              <div>
                <p className="text-sm font-medium text-gray-800">Great job this week!</p>
                <p className="text-xs text-gray-600">You've consistently tracked your recovery</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Access */}
      <div className="px-4 pb-4">
        <h3 className="font-medium text-gray-800 mb-3">Quick Access</h3>
        <div className="grid grid-cols-2 gap-3">
          
          <Button
            variant="outline"
            className="bg-white border border-gray-100 rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow h-auto flex items-center space-x-3"
            onClick={() => setLocation('/baby-profile')}
          >
            <div className="text-2xl">👶</div>
            <div>
              <h4 className="font-medium text-gray-800">Baby Care</h4>
              <p className="text-xs text-gray-600">Last feed: {getLastFeedTime()}</p>
            </div>
          </Button>

          <Button
            variant="outline"
            className="bg-white border border-gray-100 rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow h-auto flex items-center space-x-3"
            onClick={() => setLocation('/wellness')}
          >
            <div className="text-2xl">🧘‍♀️</div>
            <div>
              <h4 className="font-medium text-gray-800">Wellness</h4>
              <p className="text-xs text-gray-600">Breathing exercises</p>
            </div>
          </Button>

          <Button
            variant="outline"
            className="bg-white border border-gray-100 rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow h-auto flex items-center space-x-3"
            onClick={() => setLocation('/memory-helper')}
          >
            <div className="text-2xl">🧠</div>
            <div>
              <h4 className="font-medium text-gray-800">Memory Helper</h4>
              <p className="text-xs text-gray-600">{memoryNotes.length} notes saved</p>
            </div>
          </Button>

          <Button
            variant="outline"
            className="gentle-coral-light border border-red-200 rounded-2xl p-4 text-left shadow-sm hover:shadow-md transition-shadow h-auto flex items-center space-x-3"
            onClick={() => setLocation('/emergency')}
          >
            <div className="text-2xl">🆘</div>
            <div>
              <h4 className="font-medium text-gray-800">Emergency</h4>
              <p className="text-xs text-gray-600">Quick help & contacts</p>
            </div>
          </Button>

        </div>
      </div>

      {/* Floating Action Button */}
      <Button
        className="fixed bottom-20 right-6 w-16 h-16 bg-gradient-to-br from-soft-pink to-soft-lavender rounded-full shadow-lg hover:shadow-xl transition-shadow p-0"
        onClick={() => setShowQuickLog(true)}
      >
        <Plus className="w-6 h-6 text-white" />
      </Button>

      {/* Quick Log Modal */}
      <QuickLogModal 
        open={showQuickLog} 
        onOpenChange={setShowQuickLog}
      />
    </>
  );
}
