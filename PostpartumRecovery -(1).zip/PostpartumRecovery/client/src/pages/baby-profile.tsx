import { useState } from "react";
import { AppHeader } from "@/components/layout/app-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { BabyProfile } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ArrowLeft, Plus, Baby, Milk, Thermometer } from "lucide-react";
import { useLocation } from "wouter";

export default function BabyProfilePage() {
  const [, setLocation] = useLocation();
  const { babyProfile, updateBabyProfile } = useRecoveryData();
  const { toast } = useToast();
  
  const [showSetupDialog, setShowSetupDialog] = useState(!babyProfile);
  const [showFeedingDialog, setShowFeedingDialog] = useState(false);
  const [showDiaperDialog, setShowDiaperDialog] = useState(false);
  const [showTempDialog, setShowTempDialog] = useState(false);
  
  // Setup form
  const [name, setName] = useState(babyProfile?.name || "");
  const [birthDate, setBirthDate] = useState(babyProfile?.birthDate || "");
  const [birthWeight, setBirthWeight] = useState(babyProfile?.birthWeight?.toString() || "");
  
  // Feeding form
  const [feedingType, setFeedingType] = useState<"breast" | "bottle" | "solid">("breast");
  const [feedingDuration, setFeedingDuration] = useState("");
  const [feedingAmount, setFeedingAmount] = useState("");
  
  // Diaper form
  const [diaperType, setDiaperType] = useState<"wet" | "dirty" | "both">("wet");
  
  // Temperature form
  const [temperature, setTemperature] = useState("");

  const handleSetupProfile = () => {
    if (!name.trim() || !birthDate) {
      toast({
        title: "Error",
        description: "Please enter baby's name and birth date.",
        variant: "destructive",
      });
      return;
    }

    const profile: BabyProfile = {
      id: "baby_profile",
      name: name.trim(),
      birthDate,
      birthWeight: birthWeight ? parseFloat(birthWeight) : undefined,
      feedingLogs: [],
      diaperLogs: [],
      temperatureLogs: [],
    };

    updateBabyProfile(profile);
    
    toast({
      title: "Profile created!",
      description: "Baby profile has been set up successfully.",
    });
    
    setShowSetupDialog(false);
  };

  const handleAddFeeding = () => {
    if (!babyProfile) return;
    
    const newFeeding = {
      id: `feeding_${Date.now()}`,
      time: new Date().toISOString(),
      type: feedingType,
      duration: feedingDuration ? parseInt(feedingDuration) : undefined,
      amount: feedingAmount || undefined,
    };

    const updatedLogs = [newFeeding, ...babyProfile.feedingLogs];
    updateBabyProfile({ feedingLogs: updatedLogs });
    
    toast({
      title: "Feeding logged",
      description: "Feeding session has been recorded.",
    });
    
    setShowFeedingDialog(false);
    setFeedingDuration("");
    setFeedingAmount("");
  };

  const handleAddDiaper = () => {
    if (!babyProfile) return;
    
    const newDiaper = {
      id: `diaper_${Date.now()}`,
      time: new Date().toISOString(),
      type: diaperType,
    };

    const updatedLogs = [newDiaper, ...babyProfile.diaperLogs];
    updateBabyProfile({ diaperLogs: updatedLogs });
    
    toast({
      title: "Diaper logged",
      description: "Diaper change has been recorded.",
    });
    
    setShowDiaperDialog(false);
  };

  const handleAddTemperature = () => {
    if (!babyProfile || !temperature) return;
    
    const newTemp = {
      id: `temp_${Date.now()}`,
      time: new Date().toISOString(),
      temperature: parseFloat(temperature),
    };

    const updatedLogs = [newTemp, ...babyProfile.temperatureLogs];
    updateBabyProfile({ temperatureLogs: updatedLogs });
    
    toast({
      title: "Temperature logged",
      description: "Temperature has been recorded.",
    });
    
    setShowTempDialog(false);
    setTemperature("");
  };

  const getLastFeeding = () => {
    if (!babyProfile?.feedingLogs.length) return null;
    return babyProfile.feedingLogs[0];
  };

  const getLastDiaper = () => {
    if (!babyProfile?.diaperLogs.length) return null;
    return babyProfile.diaperLogs[0];
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${Math.floor(diffHours / 24)}d ago`;
  };

  return (
    <>
      <AppHeader />
      
      {/* Navigation Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center space-x-3">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setLocation('/')}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex items-center space-x-2">
          <Baby className="h-5 w-5 text-gray-600" />
          <h1 className="text-lg font-medium">Baby Profile</h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {babyProfile ? (
          <>
            {/* Baby Info Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span>👶</span>
                  <span>{babyProfile.name}</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-gray-600">Birth Date</Label>
                    <p className="font-medium">{format(new Date(babyProfile.birthDate), 'MMM d, yyyy')}</p>
                  </div>
                  <div>
                    <Label className="text-xs text-gray-600">Age</Label>
                    <p className="font-medium">
                      {Math.floor((Date.now() - new Date(babyProfile.birthDate).getTime()) / (1000 * 60 * 60 * 24))} days
                    </p>
                  </div>
                  {babyProfile.birthWeight && (
                    <div>
                      <Label className="text-xs text-gray-600">Birth Weight</Label>
                      <p className="font-medium">{babyProfile.birthWeight} lbs</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-3 gap-3">
              <Dialog open={showFeedingDialog} onOpenChange={setShowFeedingDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-soft-pink hover:bg-soft-pink/90 h-20 flex flex-col items-center justify-center">
                    <Milk className="h-6 w-6 mb-1" />
                    <span className="text-sm">Feed</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Log Feeding</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Feeding Type</Label>
                      <Select value={feedingType} onValueChange={(value: any) => setFeedingType(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="breast">Breastfeeding</SelectItem>
                          <SelectItem value="bottle">Bottle</SelectItem>
                          <SelectItem value="solid">Solid Food</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {feedingType !== "solid" && (
                      <div>
                        <Label>Duration (minutes)</Label>
                        <Input
                          type="number"
                          placeholder="e.g., 20"
                          value={feedingDuration}
                          onChange={(e) => setFeedingDuration(e.target.value)}
                        />
                      </div>
                    )}
                    {feedingType === "bottle" && (
                      <div>
                        <Label>Amount</Label>
                        <Input
                          placeholder="e.g., 4 oz"
                          value={feedingAmount}
                          onChange={(e) => setFeedingAmount(e.target.value)}
                        />
                      </div>
                    )}
                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={() => setShowFeedingDialog(false)} className="flex-1">
                        Cancel
                      </Button>
                      <Button onClick={handleAddFeeding} className="flex-1">
                        Log Feeding
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={showDiaperDialog} onOpenChange={setShowDiaperDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-soft-blue hover:bg-soft-blue/90 h-20 flex flex-col items-center justify-center">
                    <span className="text-2xl mb-1">💧</span>
                    <span className="text-sm">Diaper</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Log Diaper Change</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Diaper Type</Label>
                      <Select value={diaperType} onValueChange={(value: any) => setDiaperType(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="wet">Wet</SelectItem>
                          <SelectItem value="dirty">Dirty</SelectItem>
                          <SelectItem value="both">Both</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={() => setShowDiaperDialog(false)} className="flex-1">
                        Cancel
                      </Button>
                      <Button onClick={handleAddDiaper} className="flex-1">
                        Log Change
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>

              <Dialog open={showTempDialog} onOpenChange={setShowTempDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-soft-lavender hover:bg-soft-lavender/90 h-20 flex flex-col items-center justify-center">
                    <Thermometer className="h-6 w-6 mb-1" />
                    <span className="text-sm">Temp</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Log Temperature</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label>Temperature (°F)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        placeholder="e.g., 98.6"
                        value={temperature}
                        onChange={(e) => setTemperature(e.target.value)}
                      />
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={() => setShowTempDialog(false)} className="flex-1">
                        Cancel
                      </Button>
                      <Button onClick={handleAddTemperature} className="flex-1">
                        Log Temperature
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {getLastFeeding() && (
                  <div className="flex items-center justify-between p-3 soft-pink-light rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Milk className="h-5 w-5 text-soft-pink" />
                      <div>
                        <p className="text-sm font-medium">Last feeding</p>
                        <p className="text-xs text-gray-600">
                          {getLastFeeding()?.type} • {getTimeAgo(getLastFeeding()!.time)}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {getLastDiaper() && (
                  <div className="flex items-center justify-between p-3 soft-blue-light rounded-lg">
                    <div className="flex items-center space-x-3">
                      <span className="text-lg">💧</span>
                      <div>
                        <p className="text-sm font-medium">Last diaper change</p>
                        <p className="text-xs text-gray-600">
                          {getLastDiaper()?.type} • {getTimeAgo(getLastDiaper()!.time)}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {babyProfile.temperatureLogs.length > 0 && (
                  <div className="flex items-center justify-between p-3 soft-lavender-light rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Thermometer className="h-5 w-5 text-soft-lavender" />
                      <div>
                        <p className="text-sm font-medium">Last temperature</p>
                        <p className="text-xs text-gray-600">
                          {babyProfile.temperatureLogs[0].temperature}°F • {getTimeAgo(babyProfile.temperatureLogs[0].time)}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Today's Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Today's Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-soft-pink">
                      {babyProfile.feedingLogs.filter(log => 
                        format(new Date(log.time), 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
                      ).length}
                    </div>
                    <div className="text-xs text-gray-600">Feedings</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-soft-blue">
                      {babyProfile.diaperLogs.filter(log => 
                        format(new Date(log.time), 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
                      ).length}
                    </div>
                    <div className="text-xs text-gray-600">Diapers</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-soft-lavender">
                      {babyProfile.temperatureLogs.filter(log => 
                        format(new Date(log.time), 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd')
                      ).length}
                    </div>
                    <div className="text-xs text-gray-600">Temps</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          /* Setup Profile Dialog */
          <Dialog open={showSetupDialog} onOpenChange={setShowSetupDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Set Up Baby Profile</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Baby's Name</Label>
                  <Input
                    id="name"
                    placeholder="Enter baby's name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="birthDate">Birth Date</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="birthWeight">Birth Weight (lbs) - Optional</Label>
                  <Input
                    id="birthWeight"
                    type="number"
                    step="0.1"
                    placeholder="e.g., 7.5"
                    value={birthWeight}
                    onChange={(e) => setBirthWeight(e.target.value)}
                  />
                </div>
                <Button onClick={handleSetupProfile} className="w-full">
                  Create Profile
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </>
  );
}
