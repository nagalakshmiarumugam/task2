import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { MobileContainer } from "@/components/layout/mobile-container";
import { BottomNav } from "@/components/layout/bottom-nav";
import { SplashScreen } from "@/components/splash-screen";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Tracker from "@/pages/tracker";
import Reminders from "@/pages/reminders";
import LearnCenter from "@/pages/learn-center";
import Journal from "@/pages/journal";
import Progress from "@/pages/progress";
import BabyProfile from "@/pages/baby-profile";
import Wellness from "@/pages/wellness";
import MemoryHelper from "@/pages/memory-helper";
import Emergency from "@/pages/emergency";
import Profile from "@/pages/profile";
import { useState } from "react";

function Router() {
  const [, setLocation] = useLocation();
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  return (
    <MobileContainer>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/tracker" component={Tracker} />
        <Route path="/reminders" component={Reminders} />
        <Route path="/learn-center" component={LearnCenter} />
        <Route path="/journal" component={Journal} />
        <Route path="/progress" component={Progress} />
        <Route path="/baby-profile" component={BabyProfile} />
        <Route path="/wellness" component={Wellness} />
        <Route path="/memory-helper" component={MemoryHelper} />
        <Route path="/emergency" component={Emergency} />
        <Route path="/profile" component={Profile} />
        <Route component={NotFound} />
      </Switch>
      
      <BottomNav onNavigate={setLocation} />
    </MobileContainer>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
