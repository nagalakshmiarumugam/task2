import { useState } from "react";

interface PainSliderProps {
  value: number;
  onChange: (value: number) => void;
  className?: string;
}

export function PainSlider({ value, onChange, className = "" }: PainSliderProps) {
  const [isDragging, setIsDragging] = useState(false);

  const getPainColor = (level: number) => {
    if (level <= 3) return "hsl(var(--calm-green))";
    if (level <= 6) return "hsl(var(--warm-yellow))";
    return "hsl(var(--gentle-coral))";
  };

  const getPainDescription = (level: number) => {
    if (level === 0) return "No pain";
    if (level <= 3) return "Mild";
    if (level <= 6) return "Moderate";
    if (level <= 8) return "Severe";
    return "Extreme";
  };

  return (
    <div className={className}>
      <div className="mb-2 flex justify-between items-center">
        <span className="text-sm text-gray-600">Pain Level</span>
        <span 
          className="text-sm font-medium"
          style={{ color: getPainColor(value) }}
        >
          {value}/10 - {getPainDescription(value)}
        </span>
      </div>
      
      <div className="relative">
        <input
          type="range"
          min="0"
          max="10"
          value={value}
          onChange={(e) => onChange(parseInt(e.target.value))}
          onMouseDown={() => setIsDragging(true)}
          onMouseUp={() => setIsDragging(false)}
          onTouchStart={() => setIsDragging(true)}
          onTouchEnd={() => setIsDragging(false)}
          className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer pain-slider touch-target"
          style={{
            background: `linear-gradient(to right, ${getPainColor(value)} ${(value / 10) * 100}%, #e5e7eb ${(value / 10) * 100}%)`
          }}
        />
        
        {/* Pain level markers */}
        <div className="flex justify-between text-xs text-gray-400 mt-1 px-1">
          <span>0</span>
          <span>2</span>
          <span>4</span>
          <span>6</span>
          <span>8</span>
          <span>10</span>
        </div>
      </div>
    </div>
  );
}
