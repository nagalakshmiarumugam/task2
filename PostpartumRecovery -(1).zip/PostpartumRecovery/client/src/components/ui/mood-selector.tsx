import { MOOD_OPTIONS } from "@/lib/constants";

interface MoodSelectorProps {
  value?: string;
  onChange: (mood: string) => void;
  className?: string;
}

export function MoodSelector({ value, onChange, className = "" }: MoodSelectorProps) {
  return (
    <div className={`flex justify-between ${className}`}>
      {MOOD_OPTIONS.map((mood) => (
        <button
          key={mood.value}
          type="button"
          onClick={() => onChange(mood.value)}
          className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl transition-all duration-200 touch-target ${
            value === mood.value
              ? "bg-soft-pink-light border-2 border-soft-pink scale-110"
              : "bg-gray-100 hover:bg-soft-pink-light"
          }`}
        >
          {mood.emoji}
        </button>
      ))}
    </div>
  );
}
