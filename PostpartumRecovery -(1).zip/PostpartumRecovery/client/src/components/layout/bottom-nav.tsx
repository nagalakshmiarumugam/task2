import { useLocation } from "wouter";
import { Home, BarChart3, BookOpen, User } from "lucide-react";

interface BottomNavProps {
  onNavigate: (path: string) => void;
}

export function BottomNav({ onNavigate }: BottomNavProps) {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/tracker", icon: BarChart3, label: "Track" },
    { path: "/journal", icon: BookOpen, label: "Journal" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 max-w-md w-full bg-white border-t border-gray-100 px-4 py-2">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <button
              key={item.path}
              onClick={() => onNavigate(item.path)}
              className={`flex flex-col items-center py-2 transition-colors touch-target ${
                isActive 
                  ? "text-soft-pink" 
                  : "text-gray-400 hover:text-soft-blue"
              }`}
            >
              <Icon className="w-5 h-5 mb-1" />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
