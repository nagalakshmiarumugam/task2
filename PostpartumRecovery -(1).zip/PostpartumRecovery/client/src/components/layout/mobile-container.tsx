interface MobileContainerProps {
  children: React.ReactNode;
  className?: string;
}

export function MobileContainer({ children, className = "" }: MobileContainerProps) {
  return (
    <div className={`max-w-md mx-auto bg-white min-h-screen shadow-xl relative ${className}`}>
      {/* Status bar gradient */}
      <div className="bg-gradient-to-r from-soft-pink via-soft-blue to-soft-lavender h-1"></div>
      {children}
      {/* Bottom padding for navigation */}
      <div className="h-20"></div>
    </div>
  );
}
