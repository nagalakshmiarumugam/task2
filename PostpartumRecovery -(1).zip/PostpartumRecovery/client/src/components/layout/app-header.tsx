import { useRecoveryData } from "@/hooks/use-recovery-data";
import { Button } from "@/components/ui/button";
import { Settings } from "lucide-react";

interface AppHeaderProps {
  onSettingsClick?: () => void;
}

export function AppHeader({ onSettingsClick }: AppHeaderProps) {
  const { userProfile, getDaysSinceDelivery } = useRecoveryData();
  const daysSince = getDaysSinceDelivery();

  return (
    <header className="bg-white px-4 py-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-soft-pink to-soft-lavender rounded-full flex items-center justify-center">
            <span className="text-white text-lg">❤️</span>
          </div>
          <div>
            <h1 className="text-lg font-medium text-gray-800">Recovery Companion</h1>
            <p className="text-sm text-gray-500">
              Day {daysSince} postpartum
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="w-10 h-10 bg-gray-100 rounded-full"
          onClick={onSettingsClick}
        >
          <Settings className="h-5 w-5 text-gray-600" />
        </Button>
      </div>
    </header>
  );
}
