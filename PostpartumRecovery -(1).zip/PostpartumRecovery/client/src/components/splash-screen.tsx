import { useEffect, useState } from "react";
import { Heart, User } from "lucide-react";

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [animationPhase, setAnimationPhase] = useState<'fade-in' | 'visible' | 'fade-out'>('fade-in');

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setAnimationPhase('visible');
    }, 500);

    const timer2 = setTimeout(() => {
      setAnimationPhase('fade-out');
    }, 2000);

    const timer3 = setTimeout(() => {
      setIsVisible(false);
      onComplete();
    }, 2800);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onComplete]);

  if (!isVisible) return null;

  return (
    <div 
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-purple-400 via-pink-400 to-purple-600 transition-opacity duration-800 ${
        animationPhase === 'fade-in' ? 'opacity-0' : 
        animationPhase === 'visible' ? 'opacity-100' : 
        'opacity-0'
      }`}
    >
      {/* Logo Container */}
      <div className={`flex flex-col items-center space-y-6 transform transition-all duration-1000 ${
        animationPhase === 'fade-in' ? 'scale-75 translate-y-8' : 
        animationPhase === 'visible' ? 'scale-100 translate-y-0' : 
        'scale-110 translate-y-4'
      }`}>
        
        {/* Main Logo */}
        <div className="relative">
          {/* Glow Effect */}
          <div className="absolute inset-0 bg-white/30 rounded-full blur-2xl animate-pulse"></div>
          
          {/* Logo Circle */}
          <div className="relative bg-white/90 backdrop-blur-sm rounded-full p-8 shadow-2xl border border-white/50">
            <div className="flex items-center justify-center">
              {/* Custom Mother & Baby SVG Logo */}
              <svg 
                width="64" 
                height="64" 
                viewBox="0 0 64 64" 
                className="text-red-400 animate-pulse"
                fill="currentColor"
              >
                {/* Mother silhouette */}
                <circle cx="20" cy="16" r="8" opacity="0.9" />
                <path d="M12 24 C12 24, 12 32, 16 36 L24 36 C28 32, 28 24, 28 24 L12 24 Z" opacity="0.9" />
                
                {/* Baby silhouette */}
                <circle cx="44" cy="20" r="6" opacity="0.8" />
                <path d="M38 26 C38 26, 38 32, 41 35 L47 35 C50 32, 50 26, 50 26 L38 26 Z" opacity="0.8" />
                
                {/* Connecting heart shape */}
                <path d="M30 28 C30 26, 32 24, 34 26 C36 24, 38 26, 38 28 C38 32, 34 36, 34 36 C34 36, 30 32, 30 28 Z" opacity="0.7" />
              </svg>
            </div>
          </div>
        </div>

        {/* App Name */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-white drop-shadow-lg tracking-wide">
            Mumma.ai
          </h1>
          <p className="text-lg text-white/90 drop-shadow-md font-medium">
            Postpartum Recovery Companion
          </p>
        </div>

        {/* Subtitle */}
        <div className="text-center max-w-sm px-4">
          <p className="text-white/80 drop-shadow-md text-sm leading-relaxed">
            Supporting your journey to wellness, one day at a time
          </p>
        </div>

        {/* Loading Animation */}
        <div className="flex space-x-2 mt-8">
          <div className="w-2 h-2 bg-white/70 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-white/70 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
          <div className="w-2 h-2 bg-white/70 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
        </div>
      </div>

      {/* Floating Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating Elements */}
        <div className="absolute top-1/4 left-1/4 animate-float">
          <div className="w-4 h-4 bg-white/30 rounded-full"></div>
        </div>
        <div className="absolute top-1/3 right-1/4 animate-float-delayed">
          <div className="w-3 h-3 bg-white/25 rounded-full"></div>
        </div>
        <div className="absolute bottom-1/3 left-1/3 animate-float-slow">
          <div className="w-5 h-5 bg-white/35 rounded-full"></div>
        </div>
        <div className="absolute bottom-1/4 right-1/3 animate-float">
          <div className="w-4 h-4 bg-white/30 rounded-full"></div>
        </div>

        {/* Sparkle Elements */}
        <div className="absolute top-1/5 right-1/5">
          <div className="w-1 h-1 bg-white/50 rounded-full animate-ping"></div>
        </div>
        <div className="absolute bottom-1/5 left-1/5">
          <div className="w-1.5 h-1.5 bg-white/40 rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>
        </div>
        <div className="absolute top-2/5 left-1/6">
          <div className="w-1 h-1 bg-white/45 rounded-full animate-ping" style={{ animationDelay: '0.5s' }}></div>
        </div>
      </div>

      {/* Version Info */}
      <div className="absolute bottom-8 text-center">
        <p className="text-white/70 text-xs">
          v1.0.0 • Made with ❤️ for new mothers
        </p>
      </div>
    </div>
  );
}

// CSS for custom animations (to be added to index.css)
export const splashAnimations = `
@keyframes float {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  50% { transform: translateY(-10px) rotate(5deg); }
}

@keyframes float-delayed {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  50% { transform: translateY(-15px) rotate(-5deg); }
}

@keyframes float-slow {
  0%, 100% { transform: translateY(0px) rotate(0deg); }
  50% { transform: translateY(-8px) rotate(3deg); }
}

.animate-float {
  animation: float 3s ease-in-out infinite;
}

.animate-float-delayed {
  animation: float-delayed 3.5s ease-in-out infinite 1s;
}

.animate-float-slow {
  animation: float-slow 4s ease-in-out infinite 0.5s;
}
`;