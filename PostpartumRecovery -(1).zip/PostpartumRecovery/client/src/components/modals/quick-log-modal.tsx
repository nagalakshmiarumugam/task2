import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MoodSelector } from "@/components/ui/mood-selector";
import { PainSlider } from "@/components/ui/pain-slider";
import { Checkbox } from "@/components/ui/checkbox";
import { useRecoveryData } from "@/hooks/use-recovery-data";
import { DailyEntry } from "@shared/schema";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface QuickLogModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function QuickLogModal({ open, onOpenChange }: QuickLogModalProps) {
  const { addOrUpdateDailyEntry, getTodayEntry } = useRecoveryData();
  const { toast } = useToast();
  
  const todayEntry = getTodayEntry();
  
  const [mood, setMood] = useState(todayEntry?.mood.mood || "neutral");
  const [painLevel, setPainLevel] = useState(todayEntry?.pain.level || 0);
  const [sleepQuality, setSleepQuality] = useState(todayEntry?.sleep.quality || "fair");
  const [diaper, setDiaper] = useState(todayEntry?.babyCare.diaper || false);
  const [feeding, setFeeding] = useState(todayEntry?.babyCare.feeding || false);
  const [bath, setBath] = useState(todayEntry?.babyCare.bath || false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSave = async () => {
    setIsSubmitting(true);
    
    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      const entry: DailyEntry = {
        id: todayEntry?.id || `daily_${Date.now()}`,
        date: today,
        mood: {
          mood: mood as any,
          emoji: "", // Will be filled based on mood
          notes: "",
        },
        pain: {
          level: painLevel,
          notes: "",
        },
        sleep: {
          quality: sleepQuality as any,
          notes: "",
        },
        babyCare: {
          diaper,
          feeding,
          bath,
        },
        createdAt: new Date().toISOString(),
      };

      addOrUpdateDailyEntry(entry);
      
      toast({
        title: "Entry saved!",
        description: "Your daily log has been recorded.",
      });
      
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save your entry. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center">Quick Log Your Day</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Mood Selector */}
          <div>
            <label className="block text-sm text-gray-600 mb-3">How are you feeling?</label>
            <MoodSelector value={mood} onChange={setMood} />
          </div>

          {/* Pain Level Slider */}
          <PainSlider value={painLevel} onChange={setPainLevel} />

          {/* Sleep Quality */}
          <div>
            <label className="block text-sm text-gray-600 mb-2">Sleep Quality</label>
            <Select value={sleepQuality} onValueChange={setSleepQuality}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="poor">Poor</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="excellent">Excellent</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Baby Care Checklist */}
          <div>
            <label className="block text-sm text-gray-600 mb-3">Baby Care Today</label>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="diaper" 
                  checked={diaper} 
                  onCheckedChange={setDiaper}
                />
                <label htmlFor="diaper" className="text-sm">Changed diapers</label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="feeding" 
                  checked={feeding} 
                  onCheckedChange={setFeeding}
                />
                <label htmlFor="feeding" className="text-sm">Fed baby</label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="bath" 
                  checked={bath} 
                  onCheckedChange={setBath}
                />
                <label htmlFor="bath" className="text-sm">Bath time</label>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-soft-pink to-soft-lavender hover:opacity-90"
              onClick={handleSave}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Saving..." : "Save Entry"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
